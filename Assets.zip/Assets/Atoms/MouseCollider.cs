﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseCollider : MonoBehaviour {

	public Atom parent;

	//void OnMouseEnter() {
	//	parent.parent.hoveredAtom = parent.index;
	//}


}
