﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parameters : MonoBehaviour {

	public List<Stretch> stretches;
	public List<Bend> bends;
	public List<Torsion> torsions;
	public List<ImproperTorsion> improperTorsions;

	// Use this for initialization
	void Start () {
		stretches = new List<Stretch> ();
		bends = new List<Bend> ();
		torsions = new List<Torsion> ();
		improperTorsions = new List<ImproperTorsion> ();
	}

}

public class Stretch {

	public string t0;
	public string t1;
	public float req;
	public float keq;

	public Stretch(string t0, string t1, float req, float keq) {
		this.t0 = t0;
		this.t1 = t1;
		this.req = req;
		this.keq = keq;
	}
}

public class Bend {

	public string t0;
	public string t1;
	public string t2;
	public float req;
	public float keq;

	public Bend(string t0, string t1, string t2, float req, float keq) {
		this.t0 = t0;
		this.t1 = t1;
		this.t2 = t2;
		this.req = req;
		this.keq = keq;
	}
}

public class Torsion {
	public string t0;
	public string t1;
	public string t2;
	public string t3;
	public float v0;
	public float v1;
	public float v2;
	public float v3;
	public float gamma0;
	public float gamma1;
	public float gamma2;
	public float gamma3;
	public int npaths;

	public Torsion(string t0, string t1, string t2, string t3, float v0, float v1, float v2, float v3, float gamma0, float gamma1, float gamma2, float gamma3, int npaths) {
		this.t0 = t0;
		this.t1 = t1;
		this.t2 = t2;
		this.t3 = t3;
		this.v0 = v0;
		this.v1 = v1;
		this.v2 = v2;
		this.v3 = v3;
		this.gamma0 = gamma0;
		this.gamma1 = gamma1;
		this.gamma2 = gamma2;
		this.gamma3 = gamma3;
		this.npaths = npaths;
	}
}

public class ImproperTorsion {
	public string t0;
	public string t1;
	public string t2;
	public string t3;
	public float v;
	public float gamma;
	public int npaths;

	public ImproperTorsion(string t0, string t1, string t2, string t3, float v, float gamma, int npaths) {
		this.t0 = t0;
		this.t1 = t1;
		this.t2 = t2;
		this.t3 = t3;
		this.v = v;
		this.gamma = gamma;
		this.npaths = npaths;
	}
}