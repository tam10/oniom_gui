﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class FileReader: MonoBehaviour {

	public Atom atomPrefab;
	public Atoms atomsPrefab;
	public Parameters parametersPrefab;
	public Data data;
	public Settings globalSettings;

	public Atoms AtomsFromPDBFile(string path, string alternateLocationID="A") {

		Atoms atoms = Instantiate<Atoms> (atomsPrefab);
		atoms.globalSettings = globalSettings;
		atoms.setSourceFile(path, "pdb");

		atoms.name = Path.GetFileName (path);

		int index = 0;

		string[] lines = FileIO.Readlines (path, "#");
		foreach (string line in lines) {
			if (
				(
				    line.StartsWith ("ATOM") ||
				    line.StartsWith ("HETATM")
				) && (
				    line [16].ToString () == " " ||
				    line [16].ToString () == alternateLocationID
				)) {
				Atom atom = Instantiate (atomPrefab, atoms.transform);

				//See if we can use the last columns to get Atom
				bool amberUsed = false;
				string amber = line.Substring (76, 2).Trim ();
				if (amber != string.Empty) {
					atom.amberName = amber;
					foreach (Data.AmberToElement amberToElement in data.amberToElementData) {
						if (amberToElement.amberName == amber) {
							atom.element = amberToElement.element;
							atom.formalCharge = amberToElement.formalCharge;
							amberUsed = true;
						}
					}
				}

				//PDB
				atom.pdbName = line.Substring (12, 4).Trim ();

				//Use PDB to get Atom
				if (!amberUsed) {
					//If 12th column is a letter, it is a metal
					if (char.IsLetter (line [12])) {
						string element = line.Substring (12, 2).Trim ();
						atom.element = System.Text.RegularExpressions.Regex.Replace (element, @"[^a-zA-Z -]", string.Empty);
					} else {
						string element = line.Substring (12, 4).Trim ();
						atom.element = System.Text.RegularExpressions.Regex.Replace (element, @"[^a-zA-Z -]", string.Empty) [0].ToString ();
					}
				}

				//Residue
				atom.residueName = line.Substring (17, 3).Trim ();
				atom.residueNumber = int.Parse (line.Substring (22, 4).Trim ());
				atom.chainID = line [21].ToString ();

				//Position
				atom.position.x = float.Parse (line.Substring (30, 8));
				atom.position.y = float.Parse (line.Substring (38, 8));
				atom.position.z = float.Parse (line.Substring (46, 8));

				string chargeStr = line [79].ToString ();
				if (chargeStr != " ") {
					if (line [78].ToString () == "-") {
						atom.formalCharge = -int.Parse (chargeStr);
					} else {
						atom.formalCharge = int.Parse (chargeStr);
					}
				}

				atom.index = index;
				index++;
				atoms.atomList.Add (atom);

			}
		}
		return atoms;
	}

	public Parameters ParametersFromFRCMODFile(string filename) {



		Parameters parameters = Instantiate<Parameters>(parametersPrefab);

		string[] lines = FileIO.Readlines (filename);

		List<string> sections = new List<string> {
			"MASS",
			"BOND",
			"ANGL",
			"DIHEDRAL",
			"IMPROPER DIHEDRAL",
			"NONBON"
		};

		string section = "";

		foreach (string line in lines) {
			if (sections.Contains (line)) {
				section = line;
				continue;
			}

			//Ignore MASS section

			if (line == "")
				continue;
			
			if (section == "BOND") {


				////CONTINUE
			}

		}

		return parameters;

	}


}
