﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;

public class Settings : MonoBehaviour {

	public int ballResolution;
	public int stickResolution;

	// Use this for initialization
	void Awake () {
		ballResolution = 1;
		stickResolution = 1;

		GetSettings ();
	}

	void GetSettings() {
		int qualitySetting = QualitySettings.GetQualityLevel ();

		List<string> paths = new List<string>{ "Assets", Application.persistentDataPath };
		string filename = "Settings.xml";
		XDocument sX;

		foreach (string path in paths) {
			string fullpath = Path.Combine (path, filename);

			if (File.Exists (fullpath)) {
				sX = FileIO.ReadXML (fullpath);
				foreach (XElement el in sX.Element("settings").Elements("globalResolution")) {
					if (int.Parse (el.Attribute ("value").Value) == qualitySetting) {
						ballResolution = int.Parse (el.Element ("ballResolution").Value);
						stickResolution = int.Parse (el.Element ("stickResolution").Value);
					}
				}
				return;
			}
		}



	}

}
