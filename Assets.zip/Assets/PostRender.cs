﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PostRender : MonoBehaviour {

	public List<Graph> graphs;
	public Material lineMaterial;

	// Use this for initialization
	void Start () {
		graphs = new List<Graph> ();
	}

	public void AddGraph(Graph graph) {
		if (!graphs.Contains(graph))
			graphs.Add (graph);
	}

	public void RemoveGraphs(Graph graph) {
		if (graphs.Contains(graph))
			graphs.Remove (graph);
	}

	void OnPostRender() {
		DrawGLConnections ();
	}

	void OnDrawGizmos() {
		DrawGLConnections();
	}

	void DrawGLConnections() {
		if (graphs == null)
			return;

		lineMaterial.SetPass (0);
		GL.Begin (GL.LINES);
		foreach (Graph graph in graphs) {
			foreach (Connection connection in graph.connections) {

				GL.Color (connection.color0);
				GL.Vertex (connection.start);
				GL.Vertex (connection.mid);

				GL.Color (connection.color1);
				GL.Vertex (connection.mid);
				GL.Vertex (connection.end);
			}
		}
		GL.End ();
	}
}
